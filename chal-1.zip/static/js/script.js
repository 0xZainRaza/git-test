// Obfuscated AWS access key (flag) in base64 format, split into parts
const awsPart1 = btoa('TKF25{AwS');
const awsPart2 = btoa('_acc3ss_k3ys');
const awsPart3 = btoa('_leak}');

// Function to assemble the AWS access key (flag)
function getAwsAccessKey() {
    return atob(awsPart1) + atob(awsPart2) + atob(awsPart3);
}

// Fetch product data from the backend using the "AWS access key" (flag)
function fetchProducts() {
    const awsAccessKey = getAwsAccessKey(); // Flag disguised as AWS access key

    fetch(`/api/products?api_key=${awsAccessKey}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                displayProducts(data.data);
            } else {
                console.error("Invalid AWS access key");
            }
        })
        .catch(error => console.error("Error:", error));
}

// Function to display products dynamically on the page
function displayProducts(products) {
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';

    products.forEach(product => {
        const productItem = document.createElement('div');
        productItem.classList.add('product-item');
        productItem.innerHTML = `<h3>${product.name}</h3><p>Price: $${product.price}</p>`;
        productList.appendChild(productItem);
    });
}

// Fetch the products when the page loads
window.onload = fetchProducts;

