from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

# Updated list of futuristic tech products for the Tekno Fest 25 e-store
products = [
    {"id": 1, "name": "Tekno Drone", "price": 1299.99},
    {"id": 2, "name": "Holographic Projector", "price": 749.99},
    {"id": 3, "name": "AI Companion Bot", "price": 4999.99},
    {"id": 4, "name": "Quantum Computing Kit", "price": 6999.99},
    {"id": 5, "name": "Nano Fitness Tracker", "price": 199.99},
    {"id": 6, "name": "Smart Glasses XR", "price": 1599.99},
    {"id": 7, "name": "Teleportation Prototype", "price": 199999.99},
    {"id": 8, "name": "Self-Driving Bicycle", "price": 2499.99},
    {"id": 9, "name": "VR Suit MkII", "price": 3499.99}
]

# Simulated AWS access key (flag) used to validate the API request
aws_access_key = "TKF25{AwS_acc3ss_k3ys_leak}"

@app.route('/')
def home():
    return render_template('index.html')

# Simulating an API endpoint that requires a flag-like "AWS Access Key" to fetch product data
@app.route('/api/products', methods=['GET'])
def get_products():
    api_key = request.args.get('api_key')

    if api_key == aws_access_key:
        return jsonify({"status": "success", "data": products})
    else:
        return jsonify({"status": "failure", "message": "Invalid AWS access key"}), 403

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

