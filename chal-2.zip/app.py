from flask import Flask, render_template_string, request
from random import choice

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def feedback():
    user_name = ""
    if request.method == "POST":
        user_name = request.form.get("name")
    
    greeting = choice(["Hi", "Hello", "Welcome"])
    
    template = '''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>Techno Fest 25 Feedback</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 20px;
            }
            h1 {
                color: #333;
            }
            form {
                margin-bottom: 20px;
            }
            input, textarea {
                width: 100%;
                padding: 8px;
                margin: 10px 0;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            button {
                padding: 10px 15px;
                background-color: #28a745;
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }
            button:hover {
                background-color: #218838;
            }
        </style>
    </head>
    <body>
        <h1>Techno Fest 25 Feedback</h1>
        <form method="POST" action="/">
            <label for="name">Your Name:</label>
            <input type="text" id="name" name="name" required>
            <br>
            <label for="feedback">Your Feedback:</label>
            <textarea id="feedback" name="feedback" required></textarea>
            <br>
            <button type="submit">Submit</button>
        </form>

        {% if user_name %}
            <h2>''' + greeting + ' ' + user_name + '''! Thank you for your feedback!</h2>  <!-- Vulnerable reflection -->
        {% endif %}
    </body>
    </html>'''
    
    return render_template_string(template, user_name=user_name)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)

