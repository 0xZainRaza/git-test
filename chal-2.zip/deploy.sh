docker build -t techno_fest_feedback .
docker run -d -p 8080:8080 --name feedback_app techno_fest_feedback

